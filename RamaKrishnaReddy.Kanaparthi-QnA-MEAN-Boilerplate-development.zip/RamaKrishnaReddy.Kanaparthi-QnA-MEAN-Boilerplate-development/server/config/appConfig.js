// write your application configration here
const serverConfig = {
    port: 3000,
    hostname: 'localhost'
}

const dbConfig = {
    mongoUrl: 'mongodb://mongo:27017/queans'
}

/*secret key config*/
const authConfig = {
    secret: 'uns_secret_key',
    expiresIn: '10m'
}

/*Logger Configuration */
const loggerConfig = {
    appenders: {
        console: {
            type: 'console'
        },
        queansLogs: {
            type: 'file',
            filename: 'logs/queans.log'
        }
    },
    categories: {
        default: { appenders: ['console', 'queansLogs'], level: 'trace' }
    }
}

module.exports = {
    serverConfig,
    dbConfig,
    authConfig,
    loggerConfig
}