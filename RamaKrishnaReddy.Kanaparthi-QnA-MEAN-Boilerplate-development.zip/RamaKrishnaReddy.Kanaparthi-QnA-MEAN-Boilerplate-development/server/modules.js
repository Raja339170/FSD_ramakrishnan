/* Require of Mongoose connection initialization method */
const initializeMongooseConnection = require('./db/connection').createMongoConnection();
/* Require of comments entity*/
const commentModel = require('./api/v1/comments/comments.entity');
/* Require of questions entity*/
const questionModel = require('./api/v1/questions/questions.entity');
/* Require of topics entity*/
const topicModel = require('./api/v1/topics/topics.entity');
/* Require of users entity*/
const userModel = require('./api/v1/users/users.entity');
/* Method or function reference, which signs the token with given payload, expiry time and secret, call back should have error or signed token */
const signJWTToken = require('./auth').signToken;
/* Method or function reference, which verifies a given JWT Token and callback with error & payload */
const verifyJWTToken = require('./auth').verifyToken;

module.exports = {
	initializeMongooseConnection,
	commentModel,
	questionModel,
	topicModel,
	userModel,
	signJWTToken,
	verifyJWTToken
}