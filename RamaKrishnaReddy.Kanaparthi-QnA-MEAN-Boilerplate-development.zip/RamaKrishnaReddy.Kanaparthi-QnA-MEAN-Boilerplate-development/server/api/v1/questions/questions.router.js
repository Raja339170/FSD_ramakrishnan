const router = require('express').Router();
const logger = require('./../../../logger');
const questionsCtrl = require('./questions.controller');
const auth = require('./../../../auth');

//API to protect topics route
router.use(auth.verifyJWTtoken);

//API to post an question
router.post('/', (req, res) => {
    logger.debug('Inside post a question API');
    try {
        const newQuestion = req.body;
        newQuestion.topicId = req.query.topicId;
        newQuestion.userId= req.query.userId;
        newQuestion.userName= req.query.userName;
        questionsCtrl.postQuestion(newQuestion).then((response) => {
            logger.debug('Inside post question api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.question);
        }, (err) => {
            logger.error('Inside post question api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on questions.controller Post Question api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to get all questions of a Topic
router.get('/', (req, res) => {
    logger.debug('Inside Get all Questions API');
    try {
        const topicId = req.query.topicId;
        questionsCtrl.getQuestions(topicId).then((response) => {
            logger.debug('Inside get all questions api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.topicQuestions);
        }, (err) => {
            logger.error('Inside get all questions api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on questions.controller get all questions api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to get a questions of a Topic
router.get('/:questionId', (req, res) => {
    logger.debug('Inside Get all Questions API');
    try {
        const questionId = req.params.questionId;
        questionsCtrl.getQuestion(questionId).then((response) => {
            logger.debug('Inside get a question api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.topicQuestion);
        }, (err) => {
            logger.error('Inside get a question api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on questions.controller get all questions api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to update a question
router.put('/:questionId', (req, res) => {
    logger.debug('Inside update question API');
    try {
        const updatedQuestion = req.body;
        const questionId = req.params.questionId;
        questionsCtrl.updateQuestion(questionId, updatedQuestion).then((response) => {
            logger.debug('Inside update question api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.updateQuestion);
        }, (err) => {
            logger.error('Inside update question api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on questions.controller update question api', err);
        res.send({ message: 'Failed to complete request' });
    }
})

module.exports = router;