const questionModule = require('./questions.entity');
const logger = require('./../../../logger');
const uuidv1 = require('uuid/v1');

const postQuestion = (questionInfo) => {
    logger.debug('Inside questions.dao postQuestion method');
    return new Promise((resolve, reject) => {
        let newQuestion = new questionModule();
        newQuestion.id = uuidv1();
        newQuestion.question = questionInfo.question;
        newQuestion.topicId = questionInfo.topicId;
        newQuestion.userId= questionInfo.userId;
        newQuestion.userName= questionInfo.userName;
        newQuestion.save((err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            }
            else {
                resolve({ question: response, message: "Successfully posted the question", status: 201 });
            }
        });
    })
}

const getQuestions = (topicId) => {
    logger.debug('Inside questions.dao get questions method ')
    return new Promise((resolve, reject) => {
        questionModule.find({ topicId: topicId }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ topicQuestions: response, message: "Got all topic questions", status: 200 });
            }
        })
    })
}

const getQuestion = (questionId) => {
    logger.debug('Inside questions.dao get a question method ')
    return new Promise((resolve, reject) => {
        questionModule.find({ id: questionId }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ topicQuestion: response, message: "Got the question of quesionID ", status: 200 });
            }
        })
    })
}

const updateQuestion = (questionId, updatedQuestion) => {
    logger.debug('inside questions.dao update question method');
    return new Promise((resolve, reject) => {
        questionModule.findOneAndUpdate({ id: questionId }, updatedQuestion, { new: true }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ updateQuestion: response, message: 'question is updated successfully', status: 200 });
            }
        })
    })
}

module.exports = {
    postQuestion,
    getQuestions,
    getQuestion,
    updateQuestion
}