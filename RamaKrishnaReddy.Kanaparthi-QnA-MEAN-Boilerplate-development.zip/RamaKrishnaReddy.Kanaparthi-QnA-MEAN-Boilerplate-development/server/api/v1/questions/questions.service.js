const questionsDAO = require('./questions.dao');
const logger = require('./../../../logger');

const postQuestion = (questionInfo)=>{
    logger.debug('Inside postQuestion service method');
    return questionsDAO.postQuestion(questionInfo);
}

const getQuestions = (topicId)=>{
    logger.debug('Inside getQuestions service method');
    return questionsDAO.getQuestions(topicId);
}

const getQuestion = (questionId)=>{
    logger.debug('Inside getQuestion service method');
    return questionsDAO.getQuestion(questionId);
}

const updateQuestion = (questionId, updatedQuestion)=>{
    logger.debug('inside updateQuestion service method');
    return questionsDAO.updateQuestion(questionId, updatedQuestion);
}

module.exports = {
    postQuestion,
    getQuestions,
    getQuestion,
    updateQuestion
}