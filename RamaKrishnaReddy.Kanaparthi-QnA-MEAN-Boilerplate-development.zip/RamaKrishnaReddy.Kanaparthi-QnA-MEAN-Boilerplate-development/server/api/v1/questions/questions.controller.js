const questionsService = require('./questions.service');
const logger = require('./../../../logger');

const postQuestion = (questionInfo)=>{
    logger.debug('Inside postQuestion controller method');
    return questionsService.postQuestion(questionInfo);
}

const getQuestions = (topicId)=>{
    logger.debug('Inside getQuestions controller method');
    return questionsService.getQuestions(topicId);
}

const getQuestion = (questionId)=>{
    logger.debug('Inside getQuestion controller method');
    return questionsService.getQuestion(questionId);
}

const updateQuestion = (questionId, updatedQuestion)=>{
    logger.debug('inside updateQuestion controller method');
    return questionsService.updateQuestion(questionId, updatedQuestion);
}

module.exports = {
    postQuestion,
    getQuestions,
    getQuestion,
    updateQuestion
}