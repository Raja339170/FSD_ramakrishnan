const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const NoteSchema = new Schema({
    id: {
        type: String,
        unique: true,
        required: true
    },
    userId: {
        type: String,
        required: true
    },
    userName: {
        type: String,
        required: true
    },
    topic: {
        type: String,
        required: true
    }
},
    {
        timestamps: {
            createdAt: 'postedOn',
            updatedAt: 'modifiedOn'
        }
    }
);

module.exports = mongoose.model('topic', NoteSchema);