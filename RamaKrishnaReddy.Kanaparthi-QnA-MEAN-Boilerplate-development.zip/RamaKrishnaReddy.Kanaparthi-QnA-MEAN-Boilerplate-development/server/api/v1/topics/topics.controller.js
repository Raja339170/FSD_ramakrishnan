const topicsService = require('./topics.service');
const logger = require('./../../../logger');

const postTopic = (topicInfo) => {
    logger.debug('Inside postTopics controller method');
    return topicsService.postTopic(topicInfo);
}

const getTopics = (userId) => {
    logger.debug('Inside getTopics controller method');
    return topicsService.getTopics(userId);
}

const getTopic = (topicId) => {
    logger.debug('Inside getTopic controller method');
    return topicsService.getTopic(topicId);
}

const updateTopic = (topicId, updatedTopic) => {
    logger.debug('inside updateTopic controller method');
    return topicsService.updateTopic(topicId, updatedTopic);
}

module.exports = {
    postTopic,
    getTopics,
    getTopic,
    updateTopic
}