
const topicsDAO = require('./topics.dao');
const logger = require('./../../../logger');

const postTopic = (topicInfo) => {
    logger.debug('Inside postTopics Service method');
    return topicsDAO.postTopic(topicInfo);
}

const getTopics = (userId) => {
    logger.debug('Inside getTopics Service method');
    return topicsDAO.getTopics(userId);
}

const getTopic = (topicId) => {
    logger.debug('Inside getTopic Service method');
    return topicsDAO.getTopic(topicId);
}

const updateTopic = (topicId, updatedTopic) => {
    logger.debug('inside updateTopic Service method');
    return topicsDAO.updateTopic(topicId, updatedTopic);
}

module.exports = {
    postTopic,
    getTopics,
    getTopic,
    updateTopic
}