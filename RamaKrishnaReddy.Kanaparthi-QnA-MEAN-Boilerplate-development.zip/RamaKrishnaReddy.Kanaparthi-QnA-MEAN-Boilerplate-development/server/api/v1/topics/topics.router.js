const router = require('express').Router();
const logger = require('./../../../logger');
const topicsCtrl = require('./topics.controller');
const auth = require('./../../../auth');

//API to protect topics route
router.use(auth.verifyJWTtoken);

//API to post an Topic
router.post('/', (req, res) => {
    logger.debug('Inside post a topic API');
    try {
        const newTopic = req.body;
        newTopic.userId = req.query.userId;
        newTopic.userName = req.query.userName;
        topicsCtrl.postTopic(newTopic).then((response) => {
            logger.debug('Inside post topic api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.topic);
        }, (err) => {
            logger.error('Inside post topic api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on topics.controller Post topic api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to get all topics
router.get('/', (req, res) => {
    logger.debug('Inside Get all topics API');
    try {
        const userId = req.query.userId;
        topicsCtrl.getTopics(userId).then((response) => {
            logger.debug('Inside get all user topics api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.allUserTopics);
        }, (err) => {
            logger.error('Inside get all user topics api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on topics.controller get all user topics api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to get a topic
router.get('/:topicId', (req, res) => {
    logger.debug('Inside get a topic API');
    const topicId = req.params.topicId;
    try {
        topicsCtrl.getTopic(topicId).then((response) => {
            logger.debug('Inside get a topic api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.topic);
        }, (err) => {
            logger.error('Inside get a topic api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on topics.controller get a topic api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to update a topic
router.put('/:topicId', (req, res) => {
    logger.debug('Inside update topic API');
    try {
        const updatedTopic = req.body;
        const topicId = req.params.topicId;
        topicsCtrl.updateTopic(topicId, updatedTopic).then((response) => {
            logger.debug('Inside update topic api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.updateTopic);
        }, (err) => {
            logger.error('Inside update topic api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on topics.controller update topic api', err);
        res.send({ message: 'Failed to complete request' });
    }
})

module.exports = router;