const topicModule = require('./topics.entity');
const logger = require('./../../../logger');
const uuidv1 = require('uuid/v1');

const postTopic = (topicInfo) => {
    logger.debug('Inside topics.dao postTopic method');
    return new Promise((resolve, reject) => {
        let newTopic = new topicModule();
        newTopic.id = uuidv1();
        newTopic.userId = topicInfo.userId;
        newTopic.userName = topicInfo.userName;
        newTopic.topic = topicInfo.topic;
        newTopic.save((err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            }
            else {
                resolve({ topic: response, message: "Successfully posted the User Topic", status: 201 });
            }
        });
    })
}

const getTopics = (userId) => {
    logger.debug('Inside topics.dao Get topics method ')
    const query = userId ? { userId: userId } : {};
    return new Promise((resolve, reject) => {
        topicModule.find(query, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ allUserTopics: response, message: "Got all topics", status: 200 });
            }
        })
    })
}

const getTopic = (topicId) => {
    logger.debug('Inside topics.dao get topic method ')
    return new Promise((resolve, reject) => {
        topicModule.find({ id: topicId }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ topic: response, message: "Got the topic", status: 200 });
            }
        })
    })
}

const updateTopic = (topicId, updatedTopic) => {
    logger.debug('inside topics.dao update topic method');
    return new Promise((resolve, reject) => {
        topicModule.findOneAndUpdate({ id: topicId }, updatedTopic, { new: true }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ updateTopic: response, message: 'topic is updated successfully', status: 200 });
            }
        })
    })
}

module.exports = {
    postTopic,
    getTopics,
    getTopic,
    updateTopic
}