const usersDAO = require('./users.dao');
const logger = require('./../../../logger');

/* handle to register user into the system */
const registerUser = (newUserDetails) => {
    logger.debug('Inside registerUser service method');
    return usersDAO.registerUser(newUserDetails);
}

/* handle to login user into the system */
const loginUser = (userDetails) => {
    logger.debug('Inside loginUser service method');
    return usersDAO.loginUser(userDetails);
}

module.exports = {
    registerUser,
    loginUser
}