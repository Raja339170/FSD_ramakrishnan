const usersService = require('./users.service');
const logger = require('./../../../logger');

/* handle to register user into the system */
const registerUser = (newUserDetails) => {
    logger.debug('Inside registerUser controller method');
    return usersService.registerUser(newUserDetails);
}

/* handle to login user into the system */
const loginUser = (userInfo) => {
    logger.debug('Inside loginUser controller method');
    return usersService.loginUser(userInfo);
}

module.exports = {
    registerUser,
    loginUser
}

