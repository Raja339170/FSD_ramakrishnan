
const mongoose = require('mongoose');
const bcrypt = require('bcrypt-nodejs');
const Schema = mongoose.Schema;
const UserSchema = new Schema({
    userId: {
        type: String,
        required: true
    },
    fullName:{
        type: String,
        required: true
    },
    email: {
        type: String,
        lowercase: true,
        index: { unique: true },
        required: true
    },
    password: {
        type: String,
        required: true,
        minlength: [6,'Password must be atleast 6 character long']
    }
});

UserSchema.path('email').validate((val) => {
    var emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return emailRegex.test(val);
}, 'Invalid Email');

UserSchema.pre('save', function (next) {
    let user = this;

    // only hash the password if it has been modified (or is new)
    if (!user.isModified('password')) return next();

    // hash user password before saving into database
    user.password = bcrypt.hashSync(user.password, bcrypt.genSaltSync(10));
    next();
});

module.exports = mongoose.model('user', UserSchema);