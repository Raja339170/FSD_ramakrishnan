const userModule = require('./users.entity');
const logger = require('./../../../logger');
const uuidv1 = require('uuid/v1');
const bcrypt = require('bcrypt-nodejs');
const auth = require('./../../../auth');
const { authConfig } = require('./../../../config').appConfig;

const loginUser = (userDetails) => {
    logger.debug('Inside loginUser DAO method');
    return new Promise((resolve, reject) => {
        userModule.findOne({ email: userDetails.email }, (err, userInfo) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else if (!userInfo) {
                logger.info('UserEmail is not registered');
                reject({ message: 'You are not registered user', status: 403 });
            } else {
                logger.info('Checking password is correct or not');
                if (bcrypt.compareSync(userDetails.password, userInfo.password)) {
                    let payload = { email: userInfo.email, userId: userInfo.userId };
                    logger.info('Generating JWT Token for given user');
                    auth.signToken(payload, authConfig.secret, authConfig.expiresIn, (err, token) => {
                        if (err) {
                            logger.error(err);
                            reject({ message: 'Internal server error', status: 500 });
                        } else {
                            resolve({ token: token, user: { fullName: userInfo.fullName, userId: userInfo.userId }, status: 200 });
                        }
                    });
                } else {
                    reject({ message: "Password is incorrect", status: 403 });
                }
            }
        })
    })
}

const registerUser = (userDetails) => {
    logger.debug('Inside registerUser DAO method');
    return new Promise((resolve, reject) => {
        userModule.findOne({ email: userDetails.email }, (err, user) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            }
            else if (user) {
                logger.info('UserEmail is already used by another user');
                reject({ message: 'UserEmail already exist', status: 403 });
            } else {
                logger.info('Saving the user details to database');
                let newUser = new userModule();
                newUser.userId = uuidv1();
                newUser.fullName= userDetails.fullName;
                newUser.email = userDetails.email;
                newUser.password = userDetails.password;
                newUser.save((err, response) => {
                    if (err) {
                        logger.error(err);
                        reject({ message: 'Internal Server Error', status: 500 });
                    }
                    else {
                        resolve({ message: "Successfully registered new user", userInfo: response.email, status: 201 });
                    }
                });
            }
        })
    })
}

module.exports = {
    loginUser,
    registerUser
}
