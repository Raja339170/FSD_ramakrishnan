const router = require('express').Router();
const userCtrl = require('./users.controller');
const logger = require('./../../../logger');

//Api for user login 
router.post('/login', (req, res) => {
    logger.debug('Inside Login API');
    try {
        const userInfo = req.body;
        userCtrl.loginUser(userInfo).then((response) => {
            logger.debug('Inside login user on success response ');
            res.status(response.status).send(response);
        }, (err) => {
            logger.error('Inside login user on error response ', err.message);
            res.status(err.status).send(err);
        }
        );
    } catch (err) {
        logger.error('Unexpected error on user.controller Login api', err);
        res.send({ message: 'Failed to complete request' });
    }
})

//API for user registration 
router.post('/register', (req, res) => {
    logger.debug('Inside register API');
    try {
        const newUserDetails = req.body;
        userCtrl.registerUser(newUserDetails).then((response) => {
            logger.debug('Inside register user on success response ');
            logger.info(response.message);
            res.status(response.status).send(response);
        }, (err) => {
            logger.error('Inside register user on error response ', err.message);
            res.status(err.status).send(err);
        });
    } catch (err) {
        logger.error('Unexpected error on user.controller register api', err);
        res.send({ message: 'Failed to complete request' });
    }
})

module.exports = router;
