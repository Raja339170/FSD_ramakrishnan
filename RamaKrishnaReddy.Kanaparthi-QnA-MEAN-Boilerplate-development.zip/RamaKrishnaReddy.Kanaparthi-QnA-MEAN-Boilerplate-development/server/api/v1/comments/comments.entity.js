const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const NoteSchema = new Schema({
    id: {
        type: String,
        unique: true,
        required: true
    },
    comment: {
        type: String,
        required: true
    },
    questionId: {
        type: String,
        index: true,
        required: true
    },
    userId: {
        type: String,
        required: true
    },
    userName: {
        type: String,
        required: true
    }

},
    {
        timestamps: {
            createdAt: 'postedOn',
            updatedAt: 'modifiedOn'
        }
    }
);

module.exports = mongoose.model('comment', NoteSchema);