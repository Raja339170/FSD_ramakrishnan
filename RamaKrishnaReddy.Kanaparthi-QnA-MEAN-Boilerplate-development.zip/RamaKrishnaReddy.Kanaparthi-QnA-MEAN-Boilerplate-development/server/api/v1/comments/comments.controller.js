const commentsService = require('./comments.service');
const logger = require('./../../../logger');

const postComment = (commentInfo) => {
    logger.debug('Inside postComment Controller method');
    return commentsService.postComment(commentInfo);
}

const getComments = (questionId) => {
    logger.debug('Inside getComments controller method');
    return commentsService.getComments(questionId);
}

const updateComment = (commentId, updatedcomment) => {
    logger.debug('Inside updateComment controller method');
    return commentsService.updateComment(commentId, updatedcomment);
}

const deleteComment = (commentId) => {
    logger.debug('Inside deleteComment controller method');
    return commentsService.deleteComment(commentId);
}

module.exports = {
    postComment,
    getComments,
    updateComment,
    deleteComment
}