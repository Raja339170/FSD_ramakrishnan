const router = require('express').Router();
const logger = require('./../../../logger');
const commentsCtrl = require('./comments.controller');
const auth = require('./../../../auth');

//API to protect topics route
router.use(auth.verifyJWTtoken);

//API to post an comment
router.post('/', (req, res) => {
    logger.debug('Inside post a comment API');
    try {
        const newComment = req.body;
        newComment.questionId = req.query.questionId;
        newComment.userId= req.query.userId;
        newComment.userName= req.query.userName;
        commentsCtrl.postComment(newComment).then((response) => {
            logger.debug('Inside post comment api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.commentInfo);
        }, (err) => {
            logger.error('Inside post comment api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on comments.controller postComment api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to get all comments 
router.get('/', (req, res) => {
    logger.debug('Inside Get all comments API');
    try {
        const questionId = req.query.questionId;
        commentsCtrl.getComments(questionId).then((response) => {
            logger.debug('Inside get all comments api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.quecomm);
        }, (err) => {
            logger.error('Inside get all comments api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on comments.controller get all comments api', err);
        res.send({ message: 'Failed to complete request' });
    }
});

//API to update a comment
router.put('/:commentId', (req, res) => {
    logger.debug('Inside update a comment API');
    try {
        const updatedComment = req.body;
        const commentId = req.params.commentId;
        commentsCtrl.updateComment(commentId, updatedComment).then((response) => {
            logger.debug('Inside update comment api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.updateComment);
        }, (err) => {
            logger.error('Inside update comment api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on comments.controller update comment api', err);
        res.send({ message: 'Failed to complete request' });
    }
})

//API to delete a comment
router.delete('/:commentId', (req, res) => {
    logger.debug('Inside delete a comment API');
    try {
        const commentId = req.params.commentId;
        commentsCtrl.deleteComment(commentId).then((response) => {
            logger.debug('Inside delete comment api after success response');
            logger.info(response.message);
            res.status(response.status).send(response.deletedComment);
        }, (err) => {
            logger.error('Inside delete comment api after error response', err.message);
            res.status(err.status).send(err.message);
        });
    } catch (err) {
        logger.error('Unexpected error on comments.controller delete comment api', err);
        res.send({ message: 'Failed to complete request' });
    }
})

module.exports = router;