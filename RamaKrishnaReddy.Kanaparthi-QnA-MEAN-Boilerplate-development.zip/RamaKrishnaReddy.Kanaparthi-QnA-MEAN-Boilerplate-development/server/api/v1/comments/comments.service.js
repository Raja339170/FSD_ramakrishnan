const commentsDAO = require('./comments.dao');
const logger = require('./../../../logger');

const postComment = (commentInfo)=>{
    logger.debug('Inside postComment service method');
    return commentsDAO.postComment(commentInfo);
}

const getComments = (questionId)=>{
    logger.debug('Inside getComments service method');
    return commentsDAO.getComments(questionId);
}

const updateComment = (commentId, updatedComment)=>{
    logger.debug('Inside updateComment service method');
    return commentsDAO.updateComment(commentId, updatedComment);
}

const deleteComment = (commentId) => {
    logger.debug('Inside deleteComment service method');
    return commentsDAO.deleteComment(commentId);
}

module.exports = {
    postComment,
    getComments,
    updateComment,
    deleteComment
}