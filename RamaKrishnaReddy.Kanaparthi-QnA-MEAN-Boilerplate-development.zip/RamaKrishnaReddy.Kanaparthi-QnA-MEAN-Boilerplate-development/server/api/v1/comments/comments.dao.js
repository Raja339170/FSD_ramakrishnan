const commentModule = require('./comments.entity');
const logger = require('./../../../logger');
const uuidv1 = require('uuid/v1');

const postComment = (commentInfo) => {
    logger.debug('Inside comments.dao postComment method');
    return new Promise((resolve, reject) => {
        let newComment = new commentModule();
        newComment.id = uuidv1();
        newComment.comment = commentInfo.comment;
        newComment.questionId = commentInfo.questionId;
        newComment.userId = commentInfo.userId;
        newComment.userName = commentInfo.userName;
        newComment.save((err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            }
            else {
                resolve({ commentInfo: response, message: "Successfully posted the comment", status: 201 });
            }
        });
    })
}

const getComments = (questionId) => {
    logger.debug('Inside comments.dao Get question comments method ')
    return new Promise((resolve, reject) => {
        commentModule.find({ questionId: questionId }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ quecomm: response, message: "Got all question comments", status: 200 });
            }
        })
    })
}

const updateComment = (commentId, updatedComment) => {
    logger.debug('Inside comments.dao update comment method');
    return new Promise((resolve, reject) => {
        commentModule.findOneAndUpdate({ id: commentId }, updatedComment, { new: true }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ updateComment: response, message: 'Comment is updated successfully', status: 200 });
            }
        })
    })
}

const deleteComment = (commentId) => {
    logger.debug('Inside comments.dao delete comment method');
    return new Promise((resolve, reject) => {
        commentModule.findOneAndDelete({ id: commentId }, (err, response) => {
            if (err) {
                logger.error(err);
                reject({ message: 'Internal Server Error', status: 500 });
            } else {
                resolve({ deletedComment: response, message: 'Comment is deleted successfully', status: 200 });
            }
        })
    })
}

module.exports = {
    postComment,
    getComments,
    updateComment,
    deleteComment
}