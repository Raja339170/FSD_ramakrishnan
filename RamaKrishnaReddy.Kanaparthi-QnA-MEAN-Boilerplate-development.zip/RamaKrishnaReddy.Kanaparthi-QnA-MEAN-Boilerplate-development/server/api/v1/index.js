const router = require('express').Router();

//write your routes here
router.use('/topics', require('./topics'));
router.use('/questions', require('./questions'));
router.use('/comments', require('./comments'));
router.use('/users', require('./users'));

module.exports = router;