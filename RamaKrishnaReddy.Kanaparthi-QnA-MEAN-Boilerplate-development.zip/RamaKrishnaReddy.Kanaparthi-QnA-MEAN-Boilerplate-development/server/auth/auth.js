const jwt = require('jsonwebtoken');
const logger = require('./../logger');
const userModule = require('./../api/v1/users/users.entity');
const { authConfig } = require('./../config').appConfig;

const signToken = (payload, secret, expireIn, done) => {
    logger.debug('Inside signToken method')
    jwt.sign(payload, secret, { expiresIn: expireIn }, (err, token) => {
        if (err) {
            logger.error('Inside signToken method after error response', err.message);
            done(err);
        } else {
            logger.debug('Inside signToken method after success response');
            done(null, token);
        }
    })
};

const verifyToken = (token, secret, done) => {
    logger.debug('Inside verifyToken method')
    jwt.verify(token, secret, (err, authorizedData) => {
        if (err) {
            logger.error('Inside verifyToken method after error response', err.message);
            done(err.message);
        } else {
            logger.debug('Inside verifyToken method after success reponse');
            done(null, authorizedData);
        }
    })
}

//Function to protect routes
const verifyJWTtoken = (req, res, next) => {
    const header = req.headers['authorization'];
    if (typeof header !== 'undefined') {
        const bearer = header.split(' ');
        const token = bearer[1];
        req.token = token;
        verifyToken(token, authConfig.secret, (err, authorizedData) => {
            if (err) {
                logger.error('Token error occured', err);
                res.status(403).send(err);
            } else {
                logger.info('Checking authorized data is correct or not');
                userModule.findOne({ email: authorizedData.email }, (err, user) => {
                    if (err) {
                        logger.error('Inside findOne method on authorizedData after error response', err.message);
                        res.status(err.status).send(err.message);
                    } else if (!user) {
                        logger.error('User doesn\'t exist in database');
                        res.status(403).send('You cannot access the data');
                    }
                    else {
                        logger.debug('Inside findOne method on authorizedData after success response');
                        next();
                    }
                })
            }
        })
    } else {
        res.status(403).send('Not authenticated');
    }
}

module.exports = {
    signToken,
    verifyToken,
    verifyJWTtoken
}