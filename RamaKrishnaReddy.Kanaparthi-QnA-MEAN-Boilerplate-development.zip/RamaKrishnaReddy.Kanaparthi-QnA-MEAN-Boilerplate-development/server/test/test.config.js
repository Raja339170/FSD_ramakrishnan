//  Test Configuration Object
module.exports = {
  secret: 'abjwtokenxyz',
  payload: {
    email: 'abc',
    password: 'xyz'
  },
  expireIn: '10m',
  expireInSecond: '1ms',
  user: {
    email: 'admin@gmail.com',
    password: 'admin4321'
  },
  user1: {
    fullName: 'admin1',
    email: 'admin1@gmail.com',
    password: 'admin4321'
  },
  user2: {
    fullName: 'admin2',
    email: 'admin2@gmail.com',
    password: 'admin4321'
  },
  user3: {
    fullName: 'admin3',
    email: 'admin3@gmail.com',
    password: 'admin4321'
  },
  user4: {
    fullName:'admin4',
    email: 'admin4@gmail.com',
    password: 'admin4321'
  },
  user5: {
    fullName:'admin5',
    email: 'admin5@gmail.com',
    password: 'admin4321'
  },
  user6: {
    fullName:'admin6',
    email: 'admin6@gmail.com',
    password: 'admin4321'
  },
  user7: {
    fullName:'admin7',
    email: 'admin7@gmail.com',
    password: 'admin4321'
  },
  user8: {
    fullName:'admin8',
    email: 'admin8@gmail.com',
    password: 'admin4321'
  },
  user9: {
    fullName:'admin9',
    email: 'admin9@gmail.com',
    password: 'admin4321'
  },
  user10: {
    fullName:'admin10',
    email: 'admin10@gmail.com',
    password: 'admin4321'
  },
  wrongPassword: {
    email: 'admin@gmail.com',
    password: 'admin123'
  },
  wrongPassword1:{
    email: 'admin1@gmail.com',
    password: 'admin123'
  },
  wrongUserName: {
    email: 'admin11@gmail.com',
    password: 'admin123'
  },
  question_topic1: {
    question: "Where have you travelled so far?"
  },
  question_topic2: {
    question: "what is favorite color?"
  },
  question_topic3: {
    question: "who is your favorite actor?"
  },
  updateQuestion: {
    question: "what is your favorite color?"
  },
  topic1: {
    topic: 'Topic 1'
  },
  topic2: {
    topic: 'Topic 2'
  },
  topic3: {
    topic: 'Topic 3'
  },
  updateTopic: {
    topic: 'Topic Updated'
  },
  comment_topic1: {
    comment: "I travelled Switzerland, San Franciso"
  },
  comment_topic2: {
    comment: "My favourite color is red, white"
  },
  updateComment: {
    comment: "My favourite color is red, white and yellow"
  },
};
