const assert = require('chai').assert;
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const { topicModel } = require('../modules');

// getting config data 
const topic1 = config.topic1;
const topic2 = config.topic2;
const updateTopic = config.updateTopic;
const user2 = config.user2;
const user3 = config.user3;
const user4 = config.user4;

let USER_ID_1;
let USER_ID_2;
let USER_ID_3;
let jwtToken1;
let jwtToken2;
let jwtToken3;

let topicId;

const findTopic = (query, done) => {
    topicModel.findOne(query, (err, topic) => {
        if (err) {
            done(err);
        } else {
            done(null, topic);
        }
    });
}

const getTopics = (query, done) => {
    topicModel.find(query, (err, topics) => {
        if (err) {
            done(err);
        } else {
            done(null, topics)
        }
    })
}

// used to generate token
function loginUser() {
    return function (done) {
        this.timeout(4000);
        request(app)
            .post('/api/v1/users/register')
            .send(user2)
            .end(function (err, res) {
                request(app)
                    .post('/api/v1/users/register')
                    .send(user3)
                    .end(function (err, res) {
                        assert.notExists(err);
                        request(app)
                            .post('/api/v1/users/register')
                            .send(user4)
                            .end(function (err, res) {
                                request(app)
                                    .post('/api/v1/users/login')
                                    .expect(200)
                                    .send(user2)
                                    .end((err, res) => {
                                        assert.notExists(err);
                                        USER_ID_1 = res.body.user.userId
                                        jwtToken1 = res.body.token;
                                        request(app)
                                            .post('/api/v1/users/login')
                                            .expect(200)
                                            .send(user3)
                                            .end((err, res) => {
                                                assert.notExists(err);
                                                USER_ID_2 = res.body.user.userId;
                                                jwtToken2 = res.body.token;
                                                request(app)
                                                    .post('/api/v1/users/login')
                                                    .expect(200)
                                                    .send(user4)
                                                    .end((err, res) => {
                                                        assert.notExists(err);
                                                        USER_ID_3 = res.body.user.userId;
                                                        jwtToken3 = res.body.token;
                                                        done();
                                                    });
                                            });
                                    });
                            });
                    });
            });
    };
}

before(loginUser());

// //  testsuite
describe('Testing to insert a topic for users', function () {
    //  testcase
    it('Should handle a request to insert a topic 1 for user 1', function (done) {
        // Response body should have Topic name
        // status code = 201
        // response body will hold topic Name
        this.timeout(3000);
        request(app)
            .post('/api/v1/topics?userId=' + USER_ID_1)
            .set('Authorization', 'Bearer ' + jwtToken1)
            .send(topic1)
            .expect(201)
            .expect('Content-Type', /json/)
            .end(function (err, res) {
                assert.notExists(err);
                assert.exists(res.body, 'Response body should not be null or undefined');
                assert.equal(res.body.topic, 'Topic 1', 'Response body should have topic name');
                topicId = res.body.id
                findTopic({ id: topicId, userId: USER_ID_1 }, (error, topic) => {
                    if (err) {
                        assert.notExists(error);
                        done();
                    } else {
                        assert.exists(topic, 'Returning null as a response, should return topic');
                        assert.equal(topic.topic, 'Topic 1');
                        done();
                    }
                });
            });
    });

    it('Should handle a request to insert a topic 2 for user 2', function (done) {
        // Response body should have Topic name
        // status code = 201
        // response body will hold topic Name
        this.timeout(3000);
        request(app)
            .post('/api/v1/topics?userId=' + USER_ID_2)
            .set('Authorization', 'Bearer ' + jwtToken2)
            .send(topic2)
            .expect(201)
            .expect('Content-Type', /json/)
            .end(function (err, res) {
                assert.notExists(err);
                assert.exists(res.body, 'Response body should not be null or undefined');
                assert.equal(res.body.topic, 'Topic 2', 'Response body should have topic name');
                topicId = res.body.id
                findTopic({ id: topicId, userId: USER_ID_2 }, (error, topic) => {
                    if (err) {
                        assert.notExists(error);
                        done();
                    } else {
                        assert.exists(topic, 'Returning null as a response, should return topic');
                        assert.equal(topic.topic, 'Topic 2');
                        done();
                    }
                });
            });
    });
});

describe('Testing to get all the topics ', function () {

    it('Should handle request to get all the Topics of user 1', function (done) {
        // should get notes array
        // status = 200
        // response will be an non empty array
        // Pass valid token in Authorization header as Bearer
        request(app)
            .get('/api/v1/topics?userId=' + USER_ID_1)
            .set('Authorization', 'Bearer ' + jwtToken1)
            .expect(200)
            .expect('Content-Type', /json/)
            .end(function (err, res) {
                assert.notExists(err);
                assert.exists(res.body, 'Response body should not be null or undefined');
                assert.equal(res.body[res.body.length - 1].topic, 'Topic 1', 'Response should match last topic text');
                topicId = res.body[res.body.length - 1].id;
                getTopics({ userId: USER_ID_1 }, (error, topics) => {
                    if (err) {
                        assert.notExists(error);
                        done();
                    } else {
                        assert.exists(topics, 'Returning null as a response, should return topic');
                        assert.equal(topics[topics.length - 1].topic, 'Topic 1');
                        done();
                    }
                });
            });
    })

    it('Should handle request to get all the Topics of user 2', function (done) {
        // should get notes array
        // status = 200
        // response will be non empty array
        // Pass valid token in Authorization header as Bearer
        request(app)
            .get('/api/v1/topics?userId=' + USER_ID_2)
            .set('Authorization', 'Bearer ' + jwtToken2)
            .expect(200)
            .expect('Content-Type', /json/)
            .end(function (err, res) {
                assert.notExists(err);
                assert.exists(res.body, 'Response body should not be null or undefined');
                assert.equal(res.body[res.body.length - 1].topic, 'Topic 2', 'Response should match last topic text');
                topicId = res.body[res.body.length - 1].id;
                getTopics({ userId: USER_ID_2 }, (error, topics) => {
                    if (err) {
                        assert.notExists(error);
                        done();
                    } else {
                        assert.exists(topics, 'Returning null as a response, should return topic');
                        assert.equal(topics[topics.length - 1].topic, 'Topic 2');
                        done();
                    }
                });
            });
    })

    it('Should handle a request to get topics of a user who has not created any topic', function (done) {
        // should get blank array
        // status = 200
        // response will be an empty array
        // Pass valid token in Authorization header as Bearer
        request(app)
            .get('/api/v1/topics?userId=' + USER_ID_3)
            .set('Authorization', 'Bearer ' + jwtToken3)
            .expect('Content-Type', /json/)
            .end(function (err, res) {
                assert.notExists(err);
                assert.exists(res.body, 'Should return blank array of a user who has not created any note');
                assert.equal(res.body.length, 0, 'Should get blank array');
                getTopics({ userId: USER_ID_3 }, (error, notes) => {
                    if (err) {
                        assert.notExists(error);
                        done();
                    } else {
                        assert.exists(notes, 'Should return blank array of a user who has not created any note');
                        assert.equal(res.body.length, 0, 'Should get blank array');
                        done();
                    }
                });
            });
    });

});

describe('Testing to update a topic', function () {
    //   //  testcase
    it('Should handle a request to update a topic', function (done) {
        // Should return updated comment and match updated comment text value'
        // status = 200
        // response will hold updated comment as an object
        request(app)
            .put('/api/v1/topics/' + topicId)
            .set('Authorization', 'Bearer ' + jwtToken2)
            .expect('Content-Type', /json/)
            .send(updateTopic)
            .end(function (err, res) {
                assert.notExists(err);
                assert.exists(res.body, 'Returning null as a response, should return updated topic');
                assert.equal(res.body.topic, 'Topic Updated', 'Should match updated comment text');
                findTopic({ id: topicId }, (error, topic) => {
                    if (err) {
                        assert.notExists(error);
                        done();
                    } else {
                        assert.exists(topic, 'Returning null as a response, should return updated comment');
                        assert.equal(topic.topic, 'Topic Updated');
                        done();
                    }
                });
            });
    });
});




