const assert = require('chai').assert;
const { signJWTToken, verifyJWTToken } = require('../modules');
const config = require('./test.config');
let jwtToken;
const secret = config.secret;
const payload = config.payload;
const expireIn = config.expireIn;
const expireInSecond = config.expireInSecond;

describe('JWT Token test scenarios', function () {
  before(function (done) { done(); });
  after(function (done) { done(); });

  it('Assert signing & verification methods exists and are valid', function () {
    assert.notEqual(signJWTToken, undefined);
    assert.notEqual(signJWTToken, null);
    assert.equal(typeof (signJWTToken), 'function');
    assert.isAbove(signJWTToken.length, 0, 'this method must have arguments');
    assert.notEqual(verifyJWTToken, undefined);
    assert.notEqual(verifyJWTToken, null);
    assert.equal(typeof (verifyJWTToken), 'function');
    assert.isAbove(verifyJWTToken.length, 0, 'this method must have arguments');
    assert.isFunction(signJWTToken, 'signJWTToken is a function');
  });

  it('sign a token with valid payload, signature, secret and expiry time', function (done) {
    signJWTToken(payload, secret, expireIn, (err, token) => {
      if (err) {
        done(err);
      } else {
        jwtToken = token;
        assert.isAbove(token.length, 0, 'Should return a token');
        assert.notEqual(token, null, 'Token should not be null');
        assert.notEqual(token, undefined, 'Token should not be undefined');
        done();
      }
    });
  });
  it('verification of a valid signed token, must return same payload, which was passed', function (done) {
    verifyJWTToken(jwtToken, secret, (err, decoded) => {
      if (err) {
        done(err);
      } else {
        assert.equal(payload.username, decoded.username, 'Should return same payload which was given at the creation time');
        done();
      }
    });
  });

  it('verification a expired token, must return with appropriate error', function (done) {
    signJWTToken(payload, secret, expireInSecond, (err, token) => {
      if (err) {
        done(err);
      } else {
        const expiredToken = token;
        verifyJWTToken(expiredToken, secret, (err, decoded) => {
          if (err) {
            assert.equal(err, 'jwt expired', 'Should return err.message from verifyJWTToken method');
            done();
          } else {
            assert.equal(decoded, undefined, 'Should return payload as undefined if expired token passed');
            done();
          }
        });
      }
    });
  });

  it('verification a invalid, must return with appropriate error', function (done) {
    const invalidToken = 'life' + jwtToken.substring(4, jwtToken.length);
    verifyJWTToken(invalidToken, secret, (err, decoded) => {
      if (err) {
        assert.equal(err, 'invalid token', 'Should return err.message from verifyJWTToken method');
        done();
      } else {
        assert.equal(decoded, undefined, 'Should return payload as undefined if invalid token passed');
        done();
      }
    });
  });
});