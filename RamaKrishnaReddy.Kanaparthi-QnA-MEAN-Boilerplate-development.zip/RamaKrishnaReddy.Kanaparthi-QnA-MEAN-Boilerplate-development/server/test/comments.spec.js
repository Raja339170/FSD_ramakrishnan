const assert = require('chai').assert;
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const { commentModel } = require('../modules');
// getting config data 
const comment_topic1 = config.comment_topic1;
const comment_topic2 = config.comment_topic2;
const question_topic1 = config.question_topic1;
const question_topic2 = config.question_topic2;
const question_topic3 = config.question_topic3;
const updateComment = config.updateComment;
const topic1 = config.topic1;
const topic2 = config.topic2;
const topic3 = config.topic3;

const user8 = config.user8;
const user9 = config.user9;
const user10 = config.user10;

let commentId;
let QUESTION_ID_1;
let QUESTION_ID_2;
let QUESTION_ID_3;

const findComment = (query, done) => {
  commentModel.findOne(query, (err, comment) => {
    if (err) {
      done(err);
    } else {
      done(null, comment);
    }
  });
}

const getComments = (query, done) => {
  commentModel.find(query, (err, comments) => {
    if (err) {
      done(err);
    } else {
      done(null, comments);
    }
  });
}

// To get Comment Ids
function getCommentIds() {
  return function (done) {
    this.timeout(4000);
    request(app)
      .post('/api/v1/users/register')
      .send(user8)
      .end(function (err, res) {
        request(app)
          .post('/api/v1/users/register')
          .send(user9)
          .end(function (err, res) {
            assert.notExists(err);
            request(app)
              .post('/api/v1/users/register')
              .send(user10)
              .end(function (err, res) {
                request(app)
                  .post('/api/v1/users/login')
                  .expect(200)
                  .send(user8)
                  .end((err, res) => {
                    assert.notExists(err);
                    jwtToken1 = res.body.token;
                    request(app)
                      .post('/api/v1/topics?userId=' + res.body.user.userId)
                      .set('Authorization', 'Bearer ' + jwtToken1)
                      .send(topic1)
                      .end(function (err, res) {
                        assert.notExists(err);
                        request(app)
                          .post('/api/v1/questions?topicId=' + res.body.id)
                          .set('Authorization', 'Bearer ' + jwtToken1)
                          .send(question_topic1)
                          .end(function (err, res) {
                            assert.notExists(err);
                            QUESTION_ID_1 = res.body.id;
                            request(app)
                              .post('/api/v1/users/login')
                              .expect(200)
                              .send(user9)
                              .end((err, res) => {
                                assert.notExists(err);
                                jwtToken2 = res.body.token;
                                request(app)
                                  .post('/api/v1/topics?userId=' + res.body.user.userId)
                                  .set('Authorization', 'Bearer ' + jwtToken2)
                                  .send(topic2)
                                  .end(function (err, res) {
                                    assert.notExists(err);
                                    request(app)
                                      .post('/api/v1/questions?topicId=' + res.body.id)
                                      .set('Authorization', 'Bearer ' + jwtToken2)
                                      .send(question_topic2)
                                      .end(function (err, res) {
                                        assert.notExists(err);
                                        QUESTION_ID_2 = res.body.id;
                                        request(app)
                                          .post('/api/v1/users/login')
                                          .expect(200)
                                          .send(user10)
                                          .end((err, res) => {
                                            assert.notExists(err);
                                            jwtToken3 = res.body.token;
                                            request(app)
                                              .post('/api/v1/topics?userId=' + res.body.user.userId)
                                              .set('Authorization', 'Bearer ' + jwtToken3)
                                              .send(topic3)
                                              .end(function (err, res) {
                                                assert.notExists(err);
                                                request(app)
                                                  .post('/api/v1/questions?topicId=' + res.body.id)
                                                  .set('Authorization', 'Bearer ' + jwtToken3)
                                                  .send(question_topic3)
                                                  .end(function (err, res) {
                                                    assert.notExists(err);
                                                    QUESTION_ID_3 = res.body.id;
                                                    done();
                                                  });
                                              });
                                          });
                                      });
                                  });
                              });
                          });
                      });
                  });
              });
          });
      });
  };
};

// Will be called only once, before executing any testsuit.
before(getCommentIds());

// //  testsuite
describe('Testing to add a comment', function () {
  //  testcase
  it('Should handle a request to add a new comment for question 1 of topic 1', function (done) {
    // Should get added comment of topic 1 as a respone,  need to match added comment text value
    // status = 201
    // response will be added comment object
    request(app)
      .post('/api/v1/comments?questionId=' + QUESTION_ID_1)
      .set('Authorization', 'Bearer ' + jwtToken1)
      .expect(201)
      .expect('Content-Type', /json/)
      .send(comment_topic1)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return inserted comment');
        assert.equal(res.body.comment, 'I travelled Switzerland, San Franciso', 'Should match added comment text value');
        commentId = res.body.id;
        findComment({ questionId: QUESTION_ID_1, id: commentId }, (error, comment) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(comment, 'Returning null as a response, should return inserted note');
            assert.equal(comment.comment, 'I travelled Switzerland, San Franciso');
            done();
          }
        });
      });
  });

  //   //  testcase
  it('Should handle a request to add a new comment for question 2 of topic2', function (done) {
    // Should get added question of topic 2 as a respone,  need to match added question text value
    // status = 201
    // response will be added question object
    request(app)
      .post('/api/v1/comments?questionId=' + QUESTION_ID_2)
      .set('Authorization', 'Bearer ' + jwtToken2)
      .expect(201)
      .expect('Content-Type', /json/)
      .send(comment_topic2)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return inserted comment');
        assert.equal(res.body.comment, 'My favourite color is red, white', 'Should match added comment text value');
        commentId = res.body.id;
        findComment({ questionId: QUESTION_ID_2, id: commentId }, (error, comment) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(comment, 'Returning null as a response, should return inserted comment');
            assert.equal(comment.comment, 'My favourite color is red, white');
            done();
          }
        });
      });
  });
});

// //  testsuite
describe('Testing to get all comments', function () {
  //   //  testcase
  it('Should handle a request to get all comments for question 1 of topic 1', function (done) {
    // Should get all questions as a array those are created for topic 1 and Should match recently added question text value
    // status = 200
    // response will be a array or all questions those are added for topic 1
    request(app)
      .get('/api/v1/comments?questionId=' + QUESTION_ID_1)
      .set('Authorization', 'Bearer ' + jwtToken1)
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return all created comments for question 1');
        assert.equal(res.body[res.body.length - 1].comment, 'I travelled Switzerland, San Franciso', 'Should match last question text value ');
        getComments({ questionId: QUESTION_ID_1 }, (error, comments) => {
          if (err) {
            assert.exists(error);
            done();
          } else {
            assert.exists(comments, 'Returning null as a response, should return all comments of question 1');
            assert.equal(comments[comments.length - 1].comment, 'I travelled Switzerland, San Franciso');
            done();
          }
        });
      });
  });

  //  testcase
  it('Should handle a request to get all comments of a question 2', function (done) {
    // Should get all questions as a array those are created for topic 2 and Should match recently added question text value
    // status = 200
    // response will be a array or all questions those are added for topic 2
    request(app)
      .get('/api/v1/comments?questionId=' + QUESTION_ID_2)
      .set('Authorization', 'Bearer ' + jwtToken2)
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return all created comments for topic 2');
        assert.equal(res.body[res.body.length - 1].comment, 'My favourite color is red, white', 'Should match last question text value ');
        getComments({ questionId: QUESTION_ID_2 }, (error, comments) => {
          if (err) {
            assert.exists(error);
            done();
          } else {
            assert.exists(comments, 'Returning null as a response, should return all questions of topic 2');
            assert.equal(comments[comments.length - 1].comment, 'My favourite color is red, white');
            done();
          }
        });
      });
  });

  //   //  testcase
  it('Should handle a request to get comments of a question which doesnt have any comments added', function (done) {
    // should get blank array
    // status = 200
    // response will be an empty array
    request(app)
      .get('/api/v1/comments?questionId=' + QUESTION_ID_3)
      .set('Authorization', 'Bearer ' + jwtToken3)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return blank array of a comments');
        assert.equal(res.body.length, 0, 'Should get blank array');
        getComments({ questionId: 'sdgsashs' }, (error, comments) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(comments, 'Should return blank array of a questions which has no comments added');
            assert.equal(res.body.length, 0, 'Should get blank array');
            done();
          }
        });
      });
  });
});

// //  testsuite
describe('Testing to update a comment', function () {
  //   //  testcase
  it('Should handle a request to update a comment by comment id', function (done) {
    // Should return updated comment and match updated comment text value'
    // status = 200
    // response will hold updated comment as an object
    request(app)
      .put('/api/v1/comments/' + commentId)
      .set('Authorization', 'Bearer ' + jwtToken2)
      .expect('Content-Type', /json/)
      .send(updateComment)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Returning null as a response, should return updated comment');
        assert.equal(res.body.comment, 'My favourite color is red, white and yellow', 'Should match updated comment text');
        findComment({ id: commentId }, (error, comment) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(comment, 'Returning null as a response, should return updated comment');
            assert.equal(comment.comment, 'My favourite color is red, white and yellow');
            done();
          }
        });
      });
  });
});