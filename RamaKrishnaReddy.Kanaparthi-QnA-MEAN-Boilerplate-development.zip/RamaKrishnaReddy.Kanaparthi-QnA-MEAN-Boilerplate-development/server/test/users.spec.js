const assert = require('chai').assert;
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const { userModel } = require('../modules');

// getting config data
const user1 = config.user1;
const wrongPassword1 = config.wrongPassword1;
const wrongUserName = config.wrongUserName;


const findUser = (query, done) => {
  userModel.findOne(query, (err, user) => {
    if (err) {
      done(err);
    } else {
      done(null, user);
    }
  });
}

// //  testsuite
describe('Testing to register a user', function () {
  //  testcase
  it('Should handle a request to register a user', function (done) {
    // Response body should have a key as userInfo which will hold 'username' value
    // status code = 201
    // response body will hold user.userName
    this.timeout(3000);
    request(app)
      .post('/api/v1/users/register')
      .send(user1)
      .expect(201)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Response body should not be null or undefined');
        assert.equal(res.body.userInfo, 'admin1@gmail.com', 'Response body should have a key as userInfo which will hold username value');
        findUser({ email: res.body.userInfo }, (error, user) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(user, 'Returning null as a response, should return registered user');
            assert.equal(user.email, 'admin1@gmail.com');
            done();
          }
        });
      });
  });

  //   //  testcase
  it('Should handle a request to register a user multiple times with same username', function (done) {
    //Response body should have a key as message which will hold value as 'username is already exist'
    // status code = 403
    // response body will hold an object with message key
    request(app)
      .post('/api/v1/users/register')
      .send(user1)
      .expect(403)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.equal(res.body.message, 'UserEmail already exist', 'Response body should have a key as message which will hold value as UserEmail already exist');
        done();
      });
  });
});

// //  testsuite
describe('Testing to login user', function () {
  //  testcase
  it('Should handle a request to successfully login', function (done) {
    //Response body should have a key as user which will hold userName as a key and it will hold username value
    // status code = 200
    // response body will hold user.userName
    request(app)
      .post('/api/v1/users/login')
      .expect(200)
      .expect('Content-Type', /json/)
      .send(user1)
      .end(function (err, res) {
        assert.notExists(err);
        assert.isAbove(res.body.token.length, 0, 'Should return a token');
        assert.notEqual(res.body.token, null, 'Token should not be null');
        assert.notEqual(res.body.token, undefined, 'Token should not be undefined');
        assert.equal(res.body.user.email, 'admin1@gmail.com', 'Response body should have a key as user which will hold userName as a key and it will hold username value');
        done();
      });
  });

  //   //  testcase
  it('Should handle a request to login with wrong password', function (done) {
    //Response body should have a key as message which will hold value as 'Password is incorrect'
    // status code = 403
    // response body will hold an object with message key
    request(app)
      .post('/api/v1/users/login')
      .send(wrongPassword1)
      .expect('Content-Type', /json/)
      .expect(403)
      .end(function (err, res) {
        assert.notExists(err);
        assert.equal(res.body.message, 'Password is incorrect', 'Response body should have a key as message which will hold value as Password is incorrect');
        done();
      });
  });

  //   //  testcase
  it('Should handle a request to login with wrong username', function (done) {
    //Response body should have a key as message which will hold value as 'You are not registered user'
    // status code = 403
    // response body will hold an object with message key
    request(app)
      .post('/api/v1/users/login')
      .send(wrongUserName)
      .expect('Content-Type', /json/)
      .expect(403)
      .end(function (err, res) {
        assert.notExists(err);
        assert.equal(res.body.message, 'You are not registered user', 'Response body should have a key as message which will hold value as You are not registered user');
        done();
      });
  });
});