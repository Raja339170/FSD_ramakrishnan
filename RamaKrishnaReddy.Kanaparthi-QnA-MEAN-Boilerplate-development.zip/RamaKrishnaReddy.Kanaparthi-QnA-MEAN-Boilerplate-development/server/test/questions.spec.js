const assert = require('chai').assert;
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');
const { questionModel } = require('../modules');
// getting config data 
const question_topic1 = config.question_topic1;
const question_topic2 = config.question_topic2;
const updateQuestion = config.updateQuestion;
const topic1 = config.topic1;
const topic2 = config.topic2;
const topic3 = config.topic3;

const user5 = config.user5;
const user6 = config.user6;
const user7 = config.user7;

let questionId;
let TOPIC_ID_1;
let TOPIC_ID_2;
let TOPIC_ID_3;

let jwtToken1;
let jwtToken2;
let jwtToken3;

const findQuestion = (query, done) => {
  questionModel.findOne(query, (err, question) => {
    if (err) {
      done(err);
    } else {
      done(null, question);
    }
  });
}

const getQuestions = (query, done) => {
  questionModel.find(query, (err, questions) => {
    if (err) {
      done(err);
    } else {
      done(null, questions);
    }
  });
}

function getTopicIds() {
  return function (done) {
    this.timeout(4000);
    request(app)
      .post('/api/v1/users/register')
      .send(user5)
      .end(function (err, res) {
        request(app)
          .post('/api/v1/users/register')
          .send(user6)
          .end(function (err, res) {
            assert.notExists(err);
            request(app)
              .post('/api/v1/users/register')
              .send(user7)
              .end(function (err, res) {
                request(app)
                  .post('/api/v1/users/login')
                  .expect(200)
                  .send(user5)
                  .end((err, res) => {
                    assert.notExists(err);
                    jwtToken1 = res.body.token;
                    request(app)
                      .post('/api/v1/topics?userId=' + res.body.user.userId)
                      .set('Authorization', 'Bearer ' + jwtToken1)
                      .send(topic1)
                      .end(function (err, res) {
                        assert.notExists(err);
                        TOPIC_ID_1 = res.body.id;
                        request(app)
                          .post('/api/v1/users/login')
                          .expect(200)
                          .send(user6)
                          .end((err, res) => {
                            assert.notExists(err);
                            jwtToken2 = res.body.token;
                            request(app)
                              .post('/api/v1/topics?userId=' + res.body.user.userId)
                              .set('Authorization', 'Bearer ' + jwtToken2)
                              .send(topic2)
                              .end(function (err, res) {
                                assert.notExists(err);
                                TOPIC_ID_2 = res.body.id;
                                request(app)
                                  .post('/api/v1/users/login')
                                  .expect(200)
                                  .send(user7)
                                  .end((err, res) => {
                                    assert.notExists(err);
                                    jwtToken3 = res.body.token;
                                    request(app)
                                      .post('/api/v1/topics?userId=' + res.body.user.userId)
                                      .set('Authorization', 'Bearer ' + jwtToken3)
                                      .send(topic3)
                                      .end(function (err, res) {
                                        assert.notExists(err);
                                        TOPIC_ID_3 = res.body.id;
                                        done();
                                      });
                                  });
                              });
                          });
                      });
                  });
              });
          });
      });
  };
}

// Will be called only once, before executing any testsuit.
before(getTopicIds());

// //  testsuite
describe('Testing to add a question', function () {
  //  testcase
  it('Should handle a request to add a new question for topic 1 ', function (done) {
    // Should get added question of topic 1 as a respone,  need to match added question text value
    // status = 201
    // response will be added question object
    request(app)
      .post('/api/v1/questions?topicId=' + TOPIC_ID_1)
      .set('Authorization', 'Bearer ' + jwtToken1)
      .expect(201)
      .expect('Content-Type', /json/)
      .send(question_topic1)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return inserted question');
        assert.equal(res.body.question, 'Where have you travelled so far?', 'Should match added question text value');
        questionId = res.body.id;
        findQuestion({ topicId: TOPIC_ID_1, id: questionId }, (error, question) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(question, 'Returning null as a response, should return inserted note');
            assert.equal(question.question, 'Where have you travelled so far?');
            done();
          }
        });
      });
  });

  //   //  testcase
  it('Should handle a request to add a new question for topic 2 ', function (done) {
    // Should get added question of topic 2 as a respone,  need to match added question text value
    // status = 201
    // response will be added question object
    request(app)
      .post('/api/v1/questions?topicId=' + TOPIC_ID_2)
      .set('Authorization', 'Bearer ' + jwtToken2)
      .expect(201)
      .expect('Content-Type', /json/)
      .send(question_topic2)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return inserted question');
        assert.equal(res.body.question, 'what is favorite color?', 'Should match added question text value');
        questionId = res.body.id;
        findQuestion({ topicId: TOPIC_ID_2, id: questionId }, (error, question) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(question, 'Returning null as a response, should return inserted question');
            assert.equal(question.question, 'what is favorite color?');
            done();
          }
        });
      });
  });
});

// //  testsuite
describe('Testing to get all questions', function () {
  //   //  testcase
  it('Should handle a request to get all questions of a topic 1', function (done) {
    // Should get all questions as a array those are created for topic 1 and Should match recently added question text value
    // status = 200
    // response will be a array or all questions those are added for topic 1
    request(app)
      .get('/api/v1/questions?topicId=' + TOPIC_ID_1)
      .set('Authorization', 'Bearer ' + jwtToken1)
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return all created questions for topic 1');
        assert.equal(res.body[res.body.length - 1].question, 'Where have you travelled so far?', 'Should match last question text value ');
        getQuestions({ topicId: TOPIC_ID_1 }, (error, questions) => {
          if (err) {
            assert.exists(error);
            done();
          } else {
            assert.exists(questions, 'Returning null as a response, should return all questions of topic 1');
            assert.equal(questions[questions.length - 1].question, 'Where have you travelled so far?');
            done();
          }
        });
      });
  });

  //  testcase
  it('Should handle a request to get all questions of a topic 2', function (done) {
    // Should get all questions as a array those are created for topic 2 and Should match recently added question text value
    // status = 200
    // response will be a array or all questions those are added for topic 2
    request(app)
      .get('/api/v1/questions?topicId=' + TOPIC_ID_2)
      .set('Authorization', 'Bearer ' + jwtToken2)
      .expect(200)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return all created questions for topic 2');
        assert.equal(res.body[res.body.length - 1].question, 'what is favorite color?', 'Should match last question text value ');
        getQuestions({ topicId: TOPIC_ID_2 }, (error, questions) => {
          if (err) {
            assert.exists(error);
            done();
          } else {
            assert.exists(questions, 'Returning null as a response, should return all questions of topic 2');
            assert.equal(questions[questions.length - 1].question, 'what is favorite color?');
            done();
          }
        });
      });
  });

  //   //  testcase
  it('Should handle a request to get questions of a topic which doesnt have any questions added', function (done) {
    // should get blank array
    // status = 200
    // response will be an empty array
    request(app)
      .get('/api/v1/questions?topicId=' + TOPIC_ID_3)
      .set('Authorization', 'Bearer ' + jwtToken3)
      .expect('Content-Type', /json/)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Should return blank array of a questions');
        assert.equal(res.body.length, 0, 'Should get blank array');
        getQuestions({ topicId: TOPIC_ID_3 }, (error, questions) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(questions, 'Should return blank array of a topics which has no questions added');
            assert.equal(res.body.length, 0, 'Should get blank array');
            done();
          }
        });
      });
  });
});

// //  testsuite
describe('Testing to update a question', function () {
  //   //  testcase
  it('Should handle a request to update a question by question id', function (done) {
    // Should return updated question and match updated question text value'
    // status = 200
    // response will hold updated question as an object
    request(app)
      .put('/api/v1/questions/' + questionId)
      .set('Authorization', 'Bearer ' + jwtToken2)
      .expect('Content-Type', /json/)
      .send(updateQuestion)
      .end(function (err, res) {
        assert.notExists(err);
        assert.exists(res.body, 'Returning null as a response, should return updated question');
        assert.equal(res.body.question, 'what is your favorite color?', 'Should match updated question text');
        findQuestion({ id: questionId }, (error, question) => {
          if (err) {
            assert.notExists(error);
            done();
          } else {
            assert.exists(question, 'Returning null as a response, should return updated question');
            assert.equal(question.question, 'what is your favorite color?');
            done();
          }
        });
      });
  });
});