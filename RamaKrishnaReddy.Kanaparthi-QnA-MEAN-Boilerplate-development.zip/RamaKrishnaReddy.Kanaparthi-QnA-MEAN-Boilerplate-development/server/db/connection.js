// write your db connection code here
const mongoose = require('mongoose');
const { dbConfig } = require('../config').appConfig;

function createMongoConnection() {
    mongoose.connect(dbConfig.mongoUrl, { useNewUrlParser: true, useUnifiedTopology: true });
}

function getMongoConnection() {
    return mongoose.connection;
}

function onError(err) {
    console.log('Error in database connection...', err);
}

function onSuccess() {
    console.log('Connected to mongo database');
}
module.exports = {
    createMongoConnection,
    getMongoConnection,
    onError,
    onSuccess
}