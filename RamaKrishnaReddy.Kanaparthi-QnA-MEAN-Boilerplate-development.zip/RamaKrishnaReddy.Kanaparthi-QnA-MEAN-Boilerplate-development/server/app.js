const express = require('express');
const favicon = require('serve-favicon');
const path = require('path');
const app = express();
const appService = require('./app.service');

appService.connectToDatabase();
appService.corsSetup(app);
app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
appService.setAppMiddleware(app);
appService.apiSetUp(app);
appService.errorHandler404(app);

module.exports = app;
