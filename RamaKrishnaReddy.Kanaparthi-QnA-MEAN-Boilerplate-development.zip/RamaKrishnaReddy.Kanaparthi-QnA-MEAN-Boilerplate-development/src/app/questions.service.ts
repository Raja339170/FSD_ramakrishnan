import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Question } from './questions';
import { Observable } from 'rxjs/Observable';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
};

@Injectable()
export class QuestionsService {
  constructor(private http: HttpClient) { }

  // Getting all questions
  getQuestions(topicId): Observable<any> {
    return this.http.get('/api/v1/questions?topicId=' + topicId);
  }

  // To get a question
  getQuestion(questionId): Observable<any> {
    return this.http.get('/api/v1/questions/' + questionId);
  }

  // Adding a question
  addQuestion(userId, userName, topicId, newQuestion): Observable<any> {
    const body = new URLSearchParams();
    body.set('question', newQuestion);
    // tslint:disable-next-line:max-line-length
    return this.http.post('/api/v1/questions?topicId=' + topicId + '&userId=' + userId + '&userName=' + userName, body.toString(), httpOptions);
  }
}
