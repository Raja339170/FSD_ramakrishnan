export class Question {
    id: string;
    question: string;
    topicId: string;
    userId: string;
    userName: string;
}
