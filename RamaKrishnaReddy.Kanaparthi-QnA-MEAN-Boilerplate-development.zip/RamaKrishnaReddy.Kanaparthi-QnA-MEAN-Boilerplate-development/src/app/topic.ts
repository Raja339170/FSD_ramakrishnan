export class Topic {
    id: string;
    userId: string;
    userName: string;
    topic: string;
}
