export class Comment {
    id: string;
    comment: string;
    questionId: string;
    userId: string;
    userName: string;
}
