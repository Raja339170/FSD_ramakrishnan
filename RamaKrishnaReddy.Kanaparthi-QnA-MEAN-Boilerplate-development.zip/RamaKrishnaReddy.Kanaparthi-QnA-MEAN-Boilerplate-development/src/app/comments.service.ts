import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Comment } from './comments';
import { Observable } from 'rxjs/Observable';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
};

@Injectable()
export class CommentsService {

  constructor(private http: HttpClient) { }

  // Getting all comments
  getComments(questionId): Observable<any> {
    return this.http.get('/api/v1/comments?questionId=' + questionId);
  }

  // Adding a Comment
  addComment(userId, userName, questionId, newComment): Observable<any> {
    const body = new URLSearchParams();
    body.set('comment', newComment);
    // tslint:disable-next-line:max-line-length
    return this.http.post('/api/v1/comments?questionId=' + questionId + '&userId=' + userId + '&userName=' + userName, body.toString(), httpOptions);
  }

  deleteComment(commentId): Observable<any> {
    return this.http.delete('/api/v1/comments/' + commentId);
  }
}
