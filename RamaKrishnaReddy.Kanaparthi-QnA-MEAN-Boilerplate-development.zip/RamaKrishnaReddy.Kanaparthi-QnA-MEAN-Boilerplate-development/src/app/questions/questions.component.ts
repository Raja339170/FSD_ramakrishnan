import { TopicService } from './../topic.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { QuestionsService } from '../questions.service';
import { Question } from '../questions';
import { UsersService } from './../users.service';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']

})
export class QuestionsComponent implements OnInit {
  questions: Question[] = [];
  question: string;
  topicId: string = this.route.snapshot.paramMap.get('topicId');
  questionsFlag: boolean;
  topicData = {
    topic: '',
    userName: ''
  };
  userId: string = localStorage.getItem('userId');
  userName: string = localStorage.getItem('loggedUser');

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private usersService: UsersService,
    private questionService: QuestionsService,
    private topicService: TopicService,
    private location: Location
  ) { }

  ngOnInit() {
    this.getTopic();
    this.getQuestions();
  }

  getQuestions(): void {
    this.questionService.getQuestions(this.topicId)
      .subscribe(
        questions => {
          if (questions.length > 0) {
            this.questionsFlag = true;
            this.questions = questions;
            this.questions.reverse();
          } else {
            this.questionsFlag = false;
          }
        },
        err => console.log(err),
        () => console.log('Completed getting all questions'));
  }

  getTopic(): void {
    this.topicService.getTopic(this.topicId)
      .subscribe(
        data => {
          data.forEach(element => {
            this.topicData.topic = element['topic'];
            this.topicData.userName = element['userName'];
          });

        }
      );
  }

  addQuestion() {
    if (this.question && this.question.replace(/\s/g, '').length !== 0) {
      this.questionService.addQuestion(this.userId, this.userName, this.topicId, this.question)
        .subscribe(
          data => {
            this.questionsFlag = true;
            this.questions.reverse().push(data);
            this.questions.reverse();
          },
          err => console.log(err),
          () => {
            this.question = '';
            console.log('Added the given Question');
          },
      );
    } else {
      this.question = '';
      alert('Please add a valid Question');
    }
  }

  goBack(): void {
    this.location.back();
  }

  onLogout() {
    this.usersService.deleteLocalData();
    this.router.navigate(['/login']);
  }
}
