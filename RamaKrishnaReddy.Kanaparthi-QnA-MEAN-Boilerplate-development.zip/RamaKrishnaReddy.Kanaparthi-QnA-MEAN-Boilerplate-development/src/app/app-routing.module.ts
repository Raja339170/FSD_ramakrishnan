import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UsersComponent } from './users/users.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommentsComponent } from './comments/comments.component';
import { QuestionsComponent } from './questions/questions.component';
import { TopicsComponent } from './topics/topics.component';
import { SignUpComponent } from './users/sign-up/sign-up.component';
import { SignInComponent } from './users/sign-in/sign-in.component';
import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'signup', component: UsersComponent, children: [{ path: '', component: SignUpComponent }] },
  { path: 'login', component: UsersComponent, children: [{ path: '', component: SignInComponent }] },
  { path: 'dashboard/:userId/:userName', component: TopicsComponent, canActivate: [AuthGuard] },
  { path: 'questions/:topicId', component: QuestionsComponent, canActivate: [AuthGuard] },
  { path: 'comments/:questionId', component: CommentsComponent, canActivate: [AuthGuard] },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
