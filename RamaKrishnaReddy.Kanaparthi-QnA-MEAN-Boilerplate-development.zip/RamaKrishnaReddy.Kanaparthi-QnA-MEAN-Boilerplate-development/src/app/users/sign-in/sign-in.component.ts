import { UsersService } from './../../users.service';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  userName: string;

  model = {
    email: '',
    password: ''
  };

  // tslint:disable-next-line:max-line-length
  emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  serverErrorMessages: string;

  constructor(private usersService: UsersService, private router: Router) { }

  ngOnInit() {
    if (this.usersService.isLoggedIn()) {
      this.router.navigateByUrl('/dashboard/' + localStorage.getItem('userId') + '/' + localStorage.getItem('loggedUser'));
    }
  }

  onSubmit(form: NgForm) {
    this.usersService.login(form.value)
      .subscribe(
        res => {
          this.usersService.setToken(res['token']);
          this.userName = res['user'].fullName;
          localStorage.setItem('userId', res['user'].userId);
          localStorage.setItem('loggedUser', this.userName);
          this.router.navigateByUrl('/dashboard/' + res['user'].userId + '/' + this.userName);
        },
        err => {
          this.serverErrorMessages = err.error.message;
        }
      );
  }
}
