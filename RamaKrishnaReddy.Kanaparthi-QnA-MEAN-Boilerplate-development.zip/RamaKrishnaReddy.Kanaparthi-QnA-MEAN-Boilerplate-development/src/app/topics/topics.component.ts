import { AuthGuard } from './../auth/auth.guard';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { Topic } from '../topic';
import { TopicService } from '../topic.service';
import { UsersService } from './../users.service';

@Component({
  selector: 'app-topics',
  templateUrl: './topics.component.html',
  styleUrls: ['./topics.component.css']
})
export class TopicsComponent implements OnInit {
  userId: string = this.route.snapshot.paramMap.get('userId');
  userName: string = this.route.snapshot.paramMap.get('userName');
  topics: Topic[] = [];
  topicName: string;
  topicsFlag: boolean;
  config: any;
  totalTopicCount: Number = 0;

  constructor(
    private topicService: TopicService,
    private router: Router,
    private usersService: UsersService,
    private route: ActivatedRoute
  ) {
    this.config = {
      id: 'listing_pagination',
      currentPage: 1,
      itemsPerPage: 5,
      totalItems: this.totalTopicCount
    };
    this.route.queryParamMap
      .map(params => params.get('page'))
      .subscribe(page => this.config.currentPage = page);
  }

  ngOnInit() {
    this.getTopics();
  }

  getTopics() {
    this.topicService.getTopics(this.userId)
      .subscribe(
        topics => {
          if (topics.length > 0) {
            this.topicsFlag = true;
            this.topics = topics;
            this.topics.reverse(); // to display from latest to oldest
            this.totalTopicCount = topics.length;
          } else {
            this.topicsFlag = false;
          }
        },
        err => console.log(err),
        () => console.log('Completed getting all User topics'));
  }

  addTopic() {
    if (this.topicName && this.topicName.replace(/\s/g, '').length !== 0) {
      this.topicService.addTopic(this.userId, this.userName, this.topicName)
        .subscribe(
          data => {
            this.topicsFlag = true;
            this.topics.reverse().push(data);
            this.topics.reverse();
          },
          err => console.log(err),
          () => {
            this.topicName = '';
            console.log('Added the given topic');
          },
      );
    } else {
      this.topicName = '';
      alert('Please add a valid Topic Name');
    }
  }

  pageChange(newPage: number) {
    this.router.navigate(['/dashboard/' + this.userId + '/' + this.userName], { queryParams: { page: newPage } });
  }

  onLogout() {
    this.usersService.deleteLocalData();
    this.router.navigate(['/login']);
  }
}
