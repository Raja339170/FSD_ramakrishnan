export class Users {
    fullName: string;
    email: string;
    password: string;
}
