import { Users } from './users';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable()
export class UsersService {

  selectedUser: Users = {
    fullName: '',
    email: '',
    password: ''
  };

  noAuthHeader = { headers: new HttpHeaders({ 'NoAuth': 'True' }) };

  constructor(private http: HttpClient) { }

  // Http Methods
  postUser(user: Users) {
    return this.http.post('api/v1/users/register', user, this.noAuthHeader);
  }

  login(authCredentials) {
    return this.http.post('api/v1/users/login', authCredentials, this.noAuthHeader);
  }

  // Helper Methods

  setToken(token: string) {
    localStorage.setItem('token', token);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  deleteLocalData() {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('loggedUser');
  }

  getUserPayload() {
    const token = this.getToken();
    if (token) {
      const userPaylaod = atob(token.split('.')[1]);
      return JSON.parse(userPaylaod);
    } else {
      return null;
    }
  }

  isLoggedIn() {
    const userPayload = this.getUserPayload();
    if (userPayload) {
      return userPayload.exp > Date.now() / 1000;
    } else {
      return false;
    }
  }

}
