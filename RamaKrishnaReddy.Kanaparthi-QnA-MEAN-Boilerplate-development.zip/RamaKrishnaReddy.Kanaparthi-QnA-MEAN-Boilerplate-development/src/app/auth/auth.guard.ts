import { UsersService } from './../users.service';
import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private usersService: UsersService, private router: Router) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {
    if (!this.usersService.isLoggedIn()) {
      this.router.navigateByUrl('/login');
      this.usersService.deleteLocalData();
      return false;
    }
    return true;
  }
}
