import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Topic } from './topic';
import { Observable } from 'rxjs/Observable';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' })
};

@Injectable()
export class TopicService {

  constructor(private http: HttpClient) { }

  // Getting all topics
  getTopics(userId): Observable<any> {
    return this.http.get('/api/v1/topics');
  }

  // Getting a topic
  getTopic(topicId): Observable<any> {
    return this.http.get('/api/v1/topics/' + topicId);
  }

  // Adding a topic
  addTopic(userId, userName, newTopic): Observable<any> {
    const body = new URLSearchParams();
    body.set('topic', newTopic);
    return this.http.post('/api/v1/topics?userId=' + userId + '&userName=' + userName, body.toString(), httpOptions);
  }
}
