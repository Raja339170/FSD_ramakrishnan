import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { CommentsService } from '../comments.service';
import { Comment } from '../comments';
import { QuestionsService } from '../questions.service';
import { UsersService } from './../users.service';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  comments: Comment[] = [];
  comment: string;
  questionId: string = this.route.snapshot.paramMap.get('questionId');
  commentsFlag: boolean;
  questionData = {
    question: '',
    userName: ''
  };
  userId: string = localStorage.getItem('userId');
  userName: string = localStorage.getItem('loggedUser');

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private usersService: UsersService,
    private questionService: QuestionsService,
    private commentService: CommentsService,
    private location: Location
  ) { }

  ngOnInit() {
    this.getQuestion();
    this.getComments();
  }

  getComments(): void {
    this.commentService.getComments(this.questionId)
      .subscribe(
        comments => {
          if (comments.length > 0) {
            this.commentsFlag = true;
            this.comments = comments;
            this.comments.reverse();
          } else {
            this.commentsFlag = false;
          }
        },
        err => console.log(err),
        () => console.log('Completed getting all Comments'));
  }

  addComment(): void {
    if (this.comment && this.comment.replace(/\s/g, '').length !== 0) {
      this.commentService.addComment(this.userId, this.userName, this.questionId, this.comment)
        .subscribe(
          data => {
            this.commentsFlag = true;
            this.comments.reverse().push(data);
            this.comments.reverse();
          },
          err => console.log(err),
          () => {
            this.comment = '';
            console.log('Added the given Answer');
          },
      );
    } else {
      this.comment = '';
      alert('Please add a valid comment');
    }
  }

  deleteComment(commentId): void {
    if (confirm('Do you want to delete the comment?')) {
      this.commentService.deleteComment(commentId)
        .subscribe(
          data => {
            this.getComments();
          },
          err => {
            console.log(err);
          },
          () => {
            console.log('Comment deleted');
          }
        );
    }
  }

  getQuestion() {
    this.questionService.getQuestion(this.questionId)
      .subscribe(
        data => {
          data.forEach(element => {
            this.questionData.question = element['question'];
            this.questionData.userName = element['userName'];
          });
        }
      );
  }

  goBack(): void {
    this.location.back();
  }

  onLogout() {
    this.usersService.deleteLocalData();
    this.router.navigate(['/login']);
  }
}
