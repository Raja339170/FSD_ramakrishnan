# QnA Application

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.5.0.

## Running the application using Docker Compose file

Make sure you have docker installed on your Mac/Ubuntu/Windows.

We have used service names as `angular`, `express` and `mongo` respectively for 3 apps in this MEAN application in docker-compose file

Replace `mongodb://localhost:27017/queans` with `mongodb://mongo:27017/queans` in (./server/config/appConfig.js) file if not replaced 

Replace `http://localhost:3000` with `http://express:3000` in (./proxy.config.json) file if not replaced.

Make sure the ports 27017, 3000 and 4200 ports are not used by any applicaion in your local system before running docker-compose file.

Run `docker-compose up` command from the root folder of the application. 

Visit all the three apps, http://localhost:4200, http://localhost:3000/api/v1/topics or http://localhost:27017 in your local browser and you'll see that all the three containers are running.

Visit http://localhost:4200/ in your local browser to access the UI of MEAN Application

## Running the application without docker

Replace `mongodb://mongo:27017/queans` with `mongodb://localhost:27017/queans` in (./server/config/appConfig.js) file if not replaced 

Replace `http://express:3000` with `http://localhost:3000` in (./proxy.config.json) file if not replaced.

We need to run 3 apps for the mean application to work after the above steps.

### Run mongodb service 

From root folder of the this MEAN application run command `mongod --dbpath <dbpath>`in a terminal. In `<dbpath>` replace with the mongo database path. 

If the command runs without any error then the mongoDB service is up and running.

### Run Express app 

From root folder of the this MEAN application run command `cd server/ && npm start` in different terminal.

### Run Angular app 

From root folder of the application run command `npm start` in different terminal.

Visit all the three apps, http://localhost:4200, http://localhost:3000/api/v1/topics or http://localhost:27017 in your local browser and you'll see that all the 3 apps are running.

Visit http://localhost:4200/ in your local browser to access the UI of MEAN Application